class AppConstants {
  static const String baseUrl = 'https://globallib.onrender.com/api';
  static const String appName = 'City Library';
  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';
  static const int connectTimeout = 15000;
  static const int receiveTimeout = 15000;
}

class AppColors {
  static const int primary = 0xFF2563EB;
  static const int primary50 = 0xFFEFF6FF;
  static const int primary100 = 0xFFDBEAFE;
  static const int primary700 = 0xFF1D4ED8;
  static const int primary900 = 0xFF1E3A8A;
  static const int accent = 0xFFF59E0B;
  static const int success = 0xFF16A34A;
  static const int error = 0xFFDC2626;
  static const int surface = 0xFFF8FAFC;
  static const int textPrimary = 0xFF111827;
  static const int textSecondary = 0xFF6B7280;
  static const int border = 0xFFE5E7EB;
  static const int warning = 0xFFFFA000; // amber-like
}
