import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:shimmer/shimmer.dart';
import '../../models/book_model.dart';
import '../../core/constants.dart';

class BookCard extends StatelessWidget {
  final BookModel book;
  final VoidCallback? onTap;
  final VoidCallback? onReserve;

  const BookCard({super.key, required this.book, this.onTap, this.onReserve});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 140,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(AppColors.border)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0,2))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Cover
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
              child: AspectRatio(
                aspectRatio: 2/3,
                child: book.coverImage != null
                  ? CachedNetworkImage(
                      imageUrl: book.coverImage!,
                      fit: BoxFit.cover,
                      placeholder: (_, __) => _shimmer(),
                      errorWidget: (_, __, ___) => _placeholder(),
                    )
                  : _placeholder(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(book.title, maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                      color: Color(AppColors.textPrimary))),
                  const SizedBox(height: 3),
                  if (book.authorNames.isNotEmpty)
                    Text(book.authorNames.first, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10, color: Color(AppColors.textSecondary))),
                  const SizedBox(height: 6),
                  Row(children: [
                    if (book.isDigitalSale)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(color: const Color(0xFFFEF3C7), borderRadius: BorderRadius.circular(6)),
                        child: Text(book.digitalPriceDisplay ?? '\$${book.digitalPrice.toStringAsFixed(2)}',
                          style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Color(0xFFD97706))),
                      )
                    else if (book.isPhysical)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: book.isAvailable ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                          borderRadius: BorderRadius.circular(6)),
                        child: Text(book.isAvailable ? 'Available' : 'Unavailable',
                          style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600,
                            color: book.isAvailable ? const Color(0xFF15803D) : const Color(0xFFDC2626))),
                      ),
                    if (book.isDigital)
                      Container(
                        margin: const EdgeInsets.only(left: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                        decoration: BoxDecoration(color: const Color(0xFFEDE9FE), borderRadius: BorderRadius.circular(5)),
                        child: Text(book.ebookFormat?.toUpperCase() ?? 'PDF',
                          style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: Color(0xFF7C3AED))),
                      ),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _shimmer() => Shimmer.fromColors(
    baseColor: Colors.grey[200]!, highlightColor: Colors.grey[100]!,
    child: Container(color: Colors.grey[200]),
  );

  Widget _placeholder() => Container(
    color: const Color(AppColors.primary50),
    child: const Center(child: Icon(Icons.book_outlined, size: 40, color: Color(AppColors.primary))),
  );
}
