import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

class ShimmerList extends StatelessWidget {
  final int count;
  final double height;
  const ShimmerList({super.key, this.count = 5, this.height = 80});

  @override
  Widget build(BuildContext context) => ListView.separated(
    physics: const NeverScrollableScrollPhysics(),
    shrinkWrap: true,
    itemCount: count,
    separatorBuilder: (_, __) => const SizedBox(height: 12),
    itemBuilder: (_, __) => Shimmer.fromColors(
      baseColor: Colors.grey[200]!, highlightColor: Colors.grey[100]!,
      child: Container(height: height, decoration: BoxDecoration(
        color: Colors.white, borderRadius: BorderRadius.circular(12))),
    ),
  );
}
