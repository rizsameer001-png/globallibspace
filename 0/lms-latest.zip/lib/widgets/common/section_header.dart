import 'package:flutter/material.dart';
import '../../core/constants.dart';

class SectionHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  const SectionHeader({super.key, required this.title, this.subtitle, this.actionLabel, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Color(AppColors.textPrimary))),
            if (subtitle != null) Text(subtitle!, style: const TextStyle(fontSize: 12, color: Color(AppColors.textSecondary))),
          ],
        )),
        if (actionLabel != null)
          GestureDetector(
            onTap: onAction,
            child: Row(children: [
              Text(actionLabel!, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(AppColors.primary))),
              const Icon(Icons.arrow_forward_ios_rounded, size: 12, color: Color(AppColors.primary)),
            ]),
          ),
      ],
    );
  }
}
