import 'package:flutter/material.dart';
import '../models/user_model.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  UserModel? _user;
  bool _loading = false;
  String? _error;
  final _authService = AuthService();

  UserModel? get user => _user;
  bool get loading => _loading;
  String? get error => _error;
  bool get isLoggedIn => _user != null;

  Future<void> init() async {
    _user = await _authService.getStoredUser();
    notifyListeners();
  }

  Future<bool> login(String email, String password) async {
    _loading = true; _error = null; notifyListeners();
    try {
      _user = await _authService.login(email, password);
      _loading = false; notifyListeners(); return true;
    } catch (e) {
      _error = _parseError(e); _loading = false; notifyListeners(); return false;
    }
  }

  Future<bool> register(String name, String email, String password) async {
    _loading = true; _error = null; notifyListeners();
    try {
      _user = await _authService.register(name, email, password);
      _loading = false; notifyListeners(); return true;
    } catch (e) {
      _error = _parseError(e); _loading = false; notifyListeners(); return false;
    }
  }

  Future<void> logout() async {
    await _authService.logout();
    _user = null; notifyListeners();
  }

  String _parseError(dynamic e) {
    try {
      if (e.runtimeType.toString().contains('DioException')) {
        return e.response?.data?['message'] ?? 'Request failed';
      }
    } catch (_) {}
    return e.toString();
  }
}
