import 'package:flutter/material.dart';
import '../models/book_model.dart';
import '../services/api_service.dart';

class BooksProvider extends ChangeNotifier {
  final _api = ApiService();
  List<BookModel> _books = [];
  List<BookModel> _popular = [];
  BookModel? _selectedBook;
  List<BookModel> _relatedBooks = [];
  bool _loading = false;
  String? _error;
  int _page = 1, _totalPages = 1;
  String _search = '', _category = '', _bookType = '';

  List<BookModel> get books => _books;
  List<BookModel> get popular => _popular;
  BookModel? get selectedBook => _selectedBook;
  List<BookModel> get relatedBooks => _relatedBooks;
  bool get loading => _loading;
  String? get error => _error;
  bool get hasMore => _page <= _totalPages;

  Future<void> loadPopular() async {
    try {
      final res = await _api.get('/books/popular');
      _popular = (res.data['books'] as List).map((b) => BookModel.fromJson(b)).toList();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> loadBooks({bool refresh = false}) async {
    if (refresh) { _page = 1; _books = []; }
    if (!hasMore || _loading) return;
    _loading = true; notifyListeners();
    try {
      final params = <String, dynamic>{'page': _page, 'limit': 20};
      if (_search.isNotEmpty) params['search'] = _search;
      if (_category.isNotEmpty) params['category'] = _category;
      if (_bookType.isNotEmpty) params['bookType'] = _bookType;
      final res = await _api.get('/books', params: params);
      final pagination = res.data['pagination'];
      _totalPages = pagination['pages'] ?? 1;
      final newBooks = (res.data['books'] as List).map((b) => BookModel.fromJson(b)).toList();
      _books.addAll(newBooks);
      _page++;
    } catch (e) { _error = e.toString(); }
    finally { _loading = false; notifyListeners(); }
  }

  Future<void> loadBook(String id) async {
    _loading = true; notifyListeners();
    try {
      final results = await Future.wait([
        _api.get('/books/$id'),
        _api.get('/books/$id/related'),
      ]);
      _selectedBook = BookModel.fromJson(results[0].data['book']);
      _relatedBooks = (results[1].data['books'] as List).map((b) => BookModel.fromJson(b)).toList();
    } catch (e) { _error = e.toString(); }
    finally { _loading = false; notifyListeners(); }
  }

  void setSearch(String q) { _search = q; }
  void setCategory(String c) { _category = c; }
  void setBookType(String t) { _bookType = t; }

  Future<bool> reserveBook(String bookId) async {
    try {
      await _api.post('/circulation/reserve', data: {'bookId': bookId});
      return true;
    } catch (_) { return false; }
  }

  Future<String?> getDownloadUrl(String bookId) async {
    try {
      final res = await _api.get('/digital/$bookId/download');
      return res.data['url'];
    } catch (_) { return null; }
  }
}
