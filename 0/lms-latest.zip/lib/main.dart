import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'core/constants.dart';
import 'core/theme.dart';
import 'providers/auth_provider.dart';
import 'providers/books_provider.dart';
import 'services/api_service.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/books/books_screen.dart';
import 'screens/books/book_detail_screen.dart';
import 'screens/authors/authors_screen.dart';
import 'screens/authors/author_profile_screen.dart';
import 'screens/blog/blog_screen.dart';
import 'screens/blog/blog_post_screen.dart';
import 'screens/member/my_books_screen.dart';
import 'screens/member/my_downloads_screen.dart';
import 'screens/reader/reader_screen.dart';
import 'screens/profile_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  ApiService().init();
  runApp(
    MultiProvider(providers: [
      ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
      ChangeNotifierProvider(create: (_) => BooksProvider()),
    ], child: const LmsApp()),
  );
}

class LmsApp extends StatelessWidget {
  const LmsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: AppConstants.appName,
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    home: const MainShell(),
  );
}

// ── Main shell with bottom navigation ─────────────────────────────────────────
class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _tab = 0;
  // Stack-based navigation per tab
  final Map<int, GlobalKey<NavigatorState>> _navKeys = {
    0: GlobalKey(), 1: GlobalKey(), 2: GlobalKey(),
    3: GlobalKey(), 4: GlobalKey(), 5: GlobalKey(),
  };

  void _goTab(int i) => setState(() => _tab = i);

  Future<bool> _onWillPop() async {
    final nav = _navKeys[_tab];
    if (nav?.currentState?.canPop() == true) { nav!.currentState!.pop(); return false; }
    if (_tab != 0) { setState(() => _tab = 0); return false; }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: IndexedStack(index: _tab, children: [
          _buildTab(0), _buildTab(1), _buildTab(2),
          _buildTab(3), _buildTab(4), _buildTab(5),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.book_outlined), selectedIcon: Icon(Icons.book), label: 'Books'),
            NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Authors'),
            NavigationDestination(icon: Icon(Icons.article_outlined), selectedIcon: Icon(Icons.article), label: 'Blog'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'My Books'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(int i) {
    return Navigator(
      key: _navKeys[i],
      onGenerateRoute: (settings) {
        Widget screen;
        switch (i) {
          case 0: screen = HomeScreen(
            onTabChange: _goTab,
            onBookTap: (id) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => BookDetailScreen(bookId: id,
                onBookTap: (id2) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
                  builder: (_) => BookDetailScreen(bookId: id2, onBookTap: (_) {}, onReadTap: () => _navKeys[i]!.currentState!.push(MaterialPageRoute(builder: (_) => ReaderScreen(bookId: id2)))))),
                onReadTap: () => _navKeys[i]!.currentState!.push(MaterialPageRoute(builder: (_) => ReaderScreen(bookId: id)))))),
            onAuthorTap: (slug) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => AuthorProfileScreen(slug: slug,
                onBookTap: (id) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
                  builder: (_) => BookDetailScreen(bookId: id, onBookTap: (_) {}, onReadTap: () {})))))),
            onBlogTap: (slug) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => BlogPostScreen(slug: slug,
                onPostTap: (s) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
                  builder: (_) => BlogPostScreen(slug: s, onPostTap: (_) {})))))),
          ); break;

          case 1: screen = BooksScreen(
            onBookTap: (id) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => BookDetailScreen(bookId: id,
                onBookTap: (id2) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
                  builder: (_) => BookDetailScreen(bookId: id2, onBookTap: (_) {}, onReadTap: () {}))),
                onReadTap: () => _navKeys[i]!.currentState!.push(MaterialPageRoute(builder: (_) => ReaderScreen(bookId: id)))))),
          ); break;

          case 2: screen = AuthorsScreen(
            onAuthorTap: (slug) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => AuthorProfileScreen(slug: slug,
                onBookTap: (id) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
                  builder: (_) => BookDetailScreen(bookId: id, onBookTap: (_) {}, onReadTap: () {})))))),
          ); break;

          case 3: screen = BlogScreen(
            onPostTap: (slug) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => BlogPostScreen(slug: slug,
                onPostTap: (s) => _navKeys[i]!.currentState!.push(MaterialPageRoute(
                  builder: (_) => BlogPostScreen(slug: s, onPostTap: (_) {})))))),
          ); break;

          case 4: screen = Consumer<AuthProvider>(builder: (_, auth, __) {
            if (!auth.isLoggedIn) return LoginScreen(onRegister: () => _navKeys[i]!.currentState!.push(MaterialPageRoute(builder: (_) => RegisterScreen(onLogin: () => _navKeys[i]!.currentState!.pop()))));
            return MyBooksScreen();
          }); break;

          case 5: screen = ProfileScreen(
            onMyBooks:      () => _goTab(4),
            onMyDownloads:  () => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => MyDownloadsScreen(
                onReadTap: (id) => _navKeys[i]!.currentState!.push(MaterialPageRoute(builder: (_) => ReaderScreen(bookId: id)))))),
            onLogin: () => _navKeys[i]!.currentState!.push(MaterialPageRoute(
              builder: (_) => LoginScreen(
                onRegister: () => _navKeys[i]!.currentState!.push(MaterialPageRoute(builder: (_) => RegisterScreen(onLogin: () => _navKeys[i]!.currentState!.pop())))))),
          ); break;

          default: screen = const Scaffold(body: Center(child: Text('Not found')));
        }
        return MaterialPageRoute(builder: (_) => screen);
      },
    );
  }
}
