import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/books_provider.dart';
import '../../widgets/common/book_card.dart';
import '../../core/constants.dart';

class BooksScreen extends StatefulWidget {
  final Function(String) onBookTap;
  const BooksScreen({super.key, required this.onBookTap});
  @override
  State<BooksScreen> createState() => _BooksScreenState();
}

class _BooksScreenState extends State<BooksScreen> {
  final _searchCtrl = TextEditingController();
  String _selectedType = '';
  final _types = ['', 'physical', 'digital', 'both'];
  final _typeLabels = ['All', 'Physical', 'Digital', 'Both'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) =>
      context.read<BooksProvider>().loadBooks(refresh: true));
  }

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  void _applyFilters() {
    final bp = context.read<BooksProvider>();
    bp.setSearch(_searchCtrl.text.trim());
    bp.setBookType(_selectedType);
    bp.loadBooks(refresh: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Browse Books')),
      body: Column(children: [
        // Search + filter bar
        Container(
          color: Colors.white,
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Column(children: [
            TextField(
              controller: _searchCtrl,
              onSubmitted: (_) => _applyFilters(),
              decoration: InputDecoration(
                hintText: 'Search by title or author…',
                prefixIcon: const Icon(Icons.search, size: 20),
                suffixIcon: _searchCtrl.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.clear, size: 18),
                      onPressed: () { _searchCtrl.clear(); _applyFilters(); })
                  : null,
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(height: 36, child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _types.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final selected = _selectedType == _types[i];
                return GestureDetector(
                  onTap: () { setState(() => _selectedType = _types[i]); _applyFilters(); },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: selected ? const Color(AppColors.primary) : Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: selected ? const Color(AppColors.primary) : const Color(AppColors.border)),
                    ),
                    child: Text(_typeLabels[i], style: TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600,
                      color: selected ? Colors.white : const Color(AppColors.textSecondary))),
                  ),
                );
              },
            )),
          ]),
        ),
        Expanded(child: Consumer<BooksProvider>(builder: (_, bp, __) {
          if (bp.books.isEmpty && bp.loading)
            return const Center(child: CircularProgressIndicator());
          if (bp.books.isEmpty)
            return const Center(child: Text('No books found', style: TextStyle(color: Color(AppColors.textSecondary))));
          return NotificationListener<ScrollNotification>(
            onNotification: (n) {
              if (n.metrics.pixels >= n.metrics.maxScrollExtent - 200 && bp.hasMore && !bp.loading)
                bp.loadBooks();
              return false;
            },
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.55),
              itemCount: bp.books.length + (bp.loading ? 1 : 0),
              itemBuilder: (_, i) {
                if (i == bp.books.length) return const Center(child: CircularProgressIndicator());
                return BookCard(book: bp.books[i], onTap: () => widget.onBookTap(bp.books[i].id));
              },
            ),
          );
        })),
      ]),
    );
  }
}
