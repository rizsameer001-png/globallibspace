import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../providers/books_provider.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/common/book_card.dart';
import '../../core/constants.dart';

class BookDetailScreen extends StatefulWidget {
  final String bookId;
  final Function(String) onBookTap;
  final VoidCallback? onReadTap;
  const BookDetailScreen({super.key, required this.bookId, required this.onBookTap, this.onReadTap});
  @override
  State<BookDetailScreen> createState() => _BookDetailScreenState();
}

class _BookDetailScreenState extends State<BookDetailScreen> {
  bool _reserving = false, _downloading = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) =>
      context.read<BooksProvider>().loadBook(widget.bookId));
  }

  Future<void> _reserve() async {
    final auth = context.read<AuthProvider>();
    if (!auth.isLoggedIn) { _showLogin(); return; }
    setState(() => _reserving = true);
    final ok = await context.read<BooksProvider>().reserveBook(widget.bookId);
    setState(() => _reserving = false);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? 'Book reserved!' : 'Reservation failed'),
        backgroundColor: ok ? const Color(AppColors.success) : const Color(AppColors.error)));
  }

  Future<void> _download() async {
    final auth = context.read<AuthProvider>();
    if (!auth.isLoggedIn) { _showLogin(); return; }
    setState(() => _downloading = true);
    final url = await context.read<BooksProvider>().getDownloadUrl(widget.bookId);
    setState(() => _downloading = false);
    if (url != null) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Download not available')));
    }
  }

  void _showLogin() => ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('Please login to continue')));

  @override
  Widget build(BuildContext context) {
    return Consumer<BooksProvider>(builder: (_, bp, __) {
      final book = bp.selectedBook;
      if (book == null && bp.loading)
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      if (book == null)
        return Scaffold(appBar: AppBar(), body: const Center(child: Text('Book not found')));

      return Scaffold(
        body: CustomScrollView(slivers: [
          // Hero cover
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: const Color(AppColors.primary900),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(fit: StackFit.expand, children: [
                if (book.coverImage != null)
                  CachedNetworkImage(imageUrl: book.coverImage!, fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => _coverPlaceholder())
                else _coverPlaceholder(),
                Container(decoration: const BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xCC000000)]))),
                Positioned(bottom: 16, left: 16, right: 16,
                  child: Text(book.title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800))),
              ]),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(delegate: SliverChildListDelegate([
              // Authors
              if (book.authorNames.isNotEmpty) ...[
                Text('By ${book.authorNames.join(', ')}',
                  style: const TextStyle(fontSize: 15, color: Color(AppColors.primary), fontWeight: FontWeight.w600)),
                const SizedBox(height: 12),
              ],

              // Badges row
              Wrap(spacing: 8, runSpacing: 6, children: [
                ...book.categoryNames.map((c) => _badge(c, const Color(AppColors.primary50), const Color(AppColors.primary))),
                if (book.isDigital && book.ebookFormat != null)
                  _badge(book.ebookFormat!.toUpperCase(), const Color(0xFFEDE9FE), const Color(0xFF7C3AED)),
                if (book.isDigitalSale)
                  _badge(book.digitalPriceDisplay ?? '\$${book.digitalPrice}', const Color(0xFFFEF3C7), const Color(0xFFD97706)),
                if (book.isPhysical)
                  _badge(book.isAvailable ? '${book.availableCopies} available' : 'Unavailable',
                    book.isAvailable ? const Color(0xFFDCFCE7) : const Color(0xFFFEE2E2),
                    book.isAvailable ? const Color(AppColors.success) : const Color(AppColors.error)),
              ]),
              const SizedBox(height: 16),

              // Meta grid
              _metaGrid(book),
              const SizedBox(height: 16),

              // Description
              if (book.description != null) ...[
                const Text('Description', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text(book.description!, style: const TextStyle(fontSize: 14, color: Color(AppColors.textSecondary), height: 1.6)),
                const SizedBox(height: 20),
              ],

              // Action buttons
              _actionButtons(book),
              const SizedBox(height: 28),

              // Related books
              if (bp.relatedBooks.isNotEmpty) ...[
                const Text('You May Also Like', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                SizedBox(height: 220, child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: bp.relatedBooks.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 12),
                  itemBuilder: (_, i) => BookCard(book: bp.relatedBooks[i], onTap: () => widget.onBookTap(bp.relatedBooks[i].id)),
                )),
                const SizedBox(height: 20),
              ],
            ])),
          ),
        ]),
      );
    });
  }

  Widget _metaGrid(book) {
    final items = <String, String>{
      if (book.isbn != null) 'ISBN': book.isbn!,
      if (book.language != null) 'Language': book.language!,
      if (book.publicationYear != null) 'Year': book.publicationYear.toString(),
      if (book.pages != null) 'Pages': book.pages.toString(),
      'Type': book.bookType ?? 'physical',
    };
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(AppColors.surface), borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(AppColors.border))),
      child: Wrap(spacing: 16, runSpacing: 12, children: items.entries.map((e) => SizedBox(width: 130,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(e.key, style: const TextStyle(fontSize: 11, color: Color(AppColors.textSecondary))),
          Text(e.value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ]))).toList()),
    );
  }

  Widget _actionButtons(book) => Wrap(spacing: 10, runSpacing: 10, children: [
    if (book.isPhysical)
      SizedBox(width: double.infinity, child: ElevatedButton.icon(
        onPressed: _reserving ? null : _reserve,
        icon: _reserving ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Icon(Icons.bookmark_add_outlined),
        label: Text(_reserving ? 'Reserving…' : 'Reserve Book'))),
    if (book.readingEnabled)
      SizedBox(width: double.infinity, child: OutlinedButton.icon(
        onPressed: widget.onReadTap,
        icon: const Icon(Icons.menu_book_outlined),
        label: const Text('Read Online'),
        style: OutlinedButton.styleFrom(foregroundColor: const Color(AppColors.primary),
          side: const BorderSide(color: Color(AppColors.primary)),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))))),
    if (book.downloadEnabled || book.isDigitalSale)
      SizedBox(width: double.infinity, child: OutlinedButton.icon(
        onPressed: _downloading ? null : _download,
        icon: _downloading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.download_outlined),
        label: Text(book.isDigitalSale ? 'Buy & Download' : 'Free Download'),
        style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF7C3AED),
          side: const BorderSide(color: Color(0xFF7C3AED)),
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))))),
  ]);

  Widget _badge(String text, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
    child: Text(text, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg)));

  Widget _coverPlaceholder() => Container(color: const Color(AppColors.primary900),
    child: const Center(child: Icon(Icons.book, color: Colors.white54, size: 80)));
}
