import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../core/constants.dart';

class ProfileScreen extends StatefulWidget {
  final VoidCallback onMyBooks;
  final VoidCallback onMyDownloads;
  final VoidCallback onLogin;
  const ProfileScreen({super.key, required this.onMyBooks, required this.onMyDownloads, required this.onLogin});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (!auth.isLoggedIn) return _guestView();

    final user = auth.user!;
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        // Avatar card
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF1E3A8A), Color(0xFF2563EB)]),
            borderRadius: BorderRadius.circular(20)),
          child: Row(children: [
            CircleAvatar(radius: 34, backgroundColor: Colors.white24,
              child: Text(user.name[0].toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800))),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(user.name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
              Text(user.email, style: const TextStyle(color: Colors.white70, fontSize: 13)),
              const SizedBox(height: 4),
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(6)),
                child: Text(user.role.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800))),
            ])),
          ]),
        ),
        const SizedBox(height: 20),

        // Membership info
        if (user.membershipPlan != null) ...[
          _sectionTitle('Membership'),
          _listTile(Icons.card_membership_outlined, 'Plan', user.membershipPlan!),
          if (user.membershipExpiry != null)
            _listTile(Icons.event_outlined, 'Expires',
              '${user.membershipExpiry!.day}/${user.membershipExpiry!.month}/${user.membershipExpiry!.year}'),
          const SizedBox(height: 12),
        ],

        // Quick links for member
        if (user.isMember) ...[
          _sectionTitle('My Library'),
          _menuItem(Icons.book_outlined, 'My Borrowed Books', const Color(AppColors.primary), widget.onMyBooks),
          const SizedBox(height: 8),
          _menuItem(Icons.download_outlined, 'My Downloads', const Color(0xFF7C3AED), widget.onMyDownloads),
          const SizedBox(height: 12),
        ],

        _sectionTitle('Account'),
        _menuItem(Icons.person_outline, 'Edit Profile', const Color(AppColors.textSecondary), () {}),
        const SizedBox(height: 8),
        _menuItem(Icons.lock_outline, 'Change Password', const Color(AppColors.textSecondary), () {}),
        const SizedBox(height: 8),
        _menuItem(Icons.notifications_outlined, 'Notifications', const Color(AppColors.textSecondary), () {}),
        const SizedBox(height: 20),

        // Logout
        SizedBox(width: double.infinity, child: OutlinedButton.icon(
          onPressed: () async { await auth.logout(); },
          icon: const Icon(Icons.logout, color: Color(AppColors.error)),
          label: const Text('Logout', style: TextStyle(color: Color(AppColors.error), fontWeight: FontWeight.w700)),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: Color(AppColors.error)),
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
        )),
        const SizedBox(height: 20),
      ]),
    );
  }

  Widget _guestView() => Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.person_outline, size: 80, color: Color(AppColors.textSecondary)),
        const SizedBox(height: 20),
        const Text('Not logged in', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Sign in to access your library, borrows, and downloads.',
          textAlign: TextAlign.center, style: TextStyle(color: Color(AppColors.textSecondary))),
        const SizedBox(height: 28),
        ElevatedButton(onPressed: widget.onLogin, child: const Text('Sign In')),
      ]),
    )),
  );

  Widget _sectionTitle(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(t, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800,
      color: Color(AppColors.textSecondary), letterSpacing: 0.8)));

  Widget _listTile(IconData icon, String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Row(children: [
      Icon(icon, size: 18, color: const Color(AppColors.textSecondary)),
      const SizedBox(width: 8),
      Text('$label: ', style: const TextStyle(fontSize: 13, color: Color(AppColors.textSecondary))),
      Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
    ]));

  Widget _menuItem(IconData icon, String label, Color color, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(AppColors.border))),
      child: Row(children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 12),
        Expanded(child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600))),
        const Icon(Icons.chevron_right, size: 18, color: Color(AppColors.textSecondary)),
      ]),
    ),
  );
}
