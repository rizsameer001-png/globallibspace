import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../providers/auth_provider.dart';
import '../../providers/books_provider.dart';
import '../../services/api_service.dart';
import '../../models/author_model.dart';
import '../../models/book_model.dart';
import '../../models/blog_model.dart';
import '../../widgets/common/book_card.dart';
import '../../widgets/common/section_header.dart';
import '../../core/constants.dart';

class HomeScreen extends StatefulWidget {
  final Function(int) onTabChange;
  final Function(String) onBookTap;
  final Function(String) onAuthorTap;
  final Function(String) onBlogTap;
  const HomeScreen(
      {super.key,
      required this.onTabChange,
      required this.onBookTap,
      required this.onAuthorTap,
      required this.onBlogTap});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _api = ApiService();
  List<AuthorModel> _authors = [];
  List<BlogPost> _blogs = [];
  Map<String, dynamic>? _cms;
  bool _inited = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _init());
  }

  Future<void> _init() async {
    if (_inited) return;
    _inited = true;
    context.read<BooksProvider>().loadPopular();
    try {
      final results = await Future.wait([
        _api.get('/authors/featured'),
        _api.get('/blogs', params: {'limit': '3', 'featured': 'true'}),
        _api.get('/cms'),
      ]);
      if (mounted)
        setState(() {
          _authors = (results[0].data['authors'] as List)
              .map((a) => AuthorModel.fromJson(a))
              .toList();
          _blogs = (results[1].data['posts'] as List)
              .map((b) => BlogPost.fromJson(b))
              .toList();
          _cms = results[2].data['cms'];
        });
    } catch (e) {
      debugPrint("HOME ERROR: $e");
    } //catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          _inited = false;
          await _init();
        },
        child: CustomScrollView(slivers: [
          // ── Hero App Bar ──────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            backgroundColor: const Color(AppColors.primary),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF1E3A8A), Color(0xFF2563EB)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                    child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Good ${_greeting()},',
                                        style: const TextStyle(
                                            color: Colors.white70,
                                            fontSize: 13)),
                                    Text(
                                        auth.isLoggedIn
                                            ? auth.user!.name.split(' ').first
                                            : 'Reader!',
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 22,
                                            fontWeight: FontWeight.w800)),
                                  ]),
                              CircleAvatar(
                                radius: 24,
                                backgroundColor: Colors.white24,
                                child: auth.isLoggedIn
                                    ? Text(auth.user!.name[0].toUpperCase(),
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.w700,
                                            fontSize: 18))
                                    : const Icon(Icons.person,
                                        color: Colors.white),
                              ),
                            ]),
                        const SizedBox(height: 14),
                        // Search bar
                        GestureDetector(
                          onTap: () => widget.onTabChange(1),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 12),
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(14)),
                            child: Row(children: const [
                              Icon(Icons.search,
                                  color: Color(AppColors.textSecondary),
                                  size: 20),
                              SizedBox(width: 10),
                              Text('Search books, authors…',
                                  style: TextStyle(
                                      color: Color(AppColors.textSecondary),
                                      fontSize: 14)),
                            ]),
                          ),
                        ),
                      ]),
                )),
              ),
            ),
          ),

          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(
                delegate: SliverChildListDelegate([
              // ── Stats row ─────────────────────────────────────────────────
              Row(children: [
                _statBox('10K+', 'Books'),
                const SizedBox(width: 10),
                _statBox('500+', 'Authors'),
                const SizedBox(width: 10),
                _statBox('5K+', 'Members'),
              ]),
              const SizedBox(height: 24),

              // ── Popular Books ─────────────────────────────────────────────
              SectionHeader(
                title: 'Popular Books',
                subtitle: 'Most read this month',
                actionLabel: 'See all',
                onAction: () => widget.onTabChange(1),
              ),
              const SizedBox(height: 14),
              Consumer<BooksProvider>(builder: (_, bp, __) {
                if (bp.popular.isEmpty)
                  return const SizedBox(
                      height: 200,
                      child: Center(child: CircularProgressIndicator()));
                return SizedBox(
                    height: 220,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: bp.popular.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (_, i) => BookCard(
                        book: bp.popular[i],
                        onTap: () => widget.onBookTap(bp.popular[i].id),
                      ),
                    ));
              }),
              const SizedBox(height: 28),

              // ── Featured Authors ──────────────────────────────────────────
              if (_authors.isNotEmpty) ...[
                SectionHeader(
                    title: 'Featured Authors',
                    actionLabel: 'See all',
                    onAction: () => widget.onTabChange(3)),
                const SizedBox(height: 14),
                SizedBox(
                    height: 110,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _authors.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 16),
                      itemBuilder: (_, i) {
                        final a = _authors[i];
                        return GestureDetector(
                          onTap: () => widget.onAuthorTap(a.profileId),
                          child: Column(children: [
                            CircleAvatar(
                                radius: 36,
                                backgroundImage: a.avatar != null
                                    ? CachedNetworkImageProvider(a.avatar!)
                                    : null,
                                backgroundColor:
                                    const Color(AppColors.primary100),
                                child: a.avatar == null
                                    ? Text(a.name[0],
                                        style: const TextStyle(
                                            fontSize: 22,
                                            fontWeight: FontWeight.w700,
                                            color: Color(AppColors.primary)))
                                    : null),
                            const SizedBox(height: 6),
                            SizedBox(
                                width: 72,
                                child: Text(a.name,
                                    textAlign: TextAlign.center,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600))),
                          ]),
                        );
                      },
                    )),
                const SizedBox(height: 28),
              ],

              // ── Latest Blog ───────────────────────────────────────────────
              if (_blogs.isNotEmpty) ...[
                SectionHeader(
                    title: 'From Our Blog',
                    actionLabel: 'See all',
                    onAction: () => widget.onTabChange(4)),
                const SizedBox(height: 14),
                ..._blogs.map((post) => _blogCard(post)),
                const SizedBox(height: 28),
              ],

              // ── CTA for guests ────────────────────────────────────────────
              if (!auth.isLoggedIn) _ctaBanner(),
              const SizedBox(height: 20),
            ])),
          ),
        ]),
      ),
    );
  }

  Widget _statBox(String value, String label) => Expanded(
          child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(AppColors.border))),
        child: Column(children: [
          Text(value,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: Color(AppColors.primary))),
          Text(label,
              style: const TextStyle(
                  fontSize: 11, color: Color(AppColors.textSecondary))),
        ]),
      ));

  Widget _blogCard(BlogPost post) => GestureDetector(
        onTap: () => widget.onBlogTap(post.postId),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(AppColors.border))),
          child: Row(children: [
            ClipRRect(
                borderRadius:
                    const BorderRadius.horizontal(left: Radius.circular(14)),
                child: SizedBox(
                    width: 90,
                    height: 80,
                    child: post.coverImage != null
                        ? CachedNetworkImage(
                            imageUrl: post.coverImage!,
                            fit: BoxFit.cover,
                            errorWidget: (_, __, ___) => _blogPlaceholder())
                        : _blogPlaceholder())),
            Expanded(
                child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (post.category != null)
                      Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                              color: const Color(AppColors.primary50),
                              borderRadius: BorderRadius.circular(6)),
                          child: Text(post.category!,
                              style: const TextStyle(
                                  fontSize: 9,
                                  fontWeight: FontWeight.w700,
                                  color: Color(AppColors.primary)))),
                    const SizedBox(height: 4),
                    Text(post.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text('${post.readTime} min read',
                        style: const TextStyle(
                            fontSize: 11,
                            color: Color(AppColors.textSecondary))),
                  ]),
            )),
          ]),
        ),
      );

  Widget _blogPlaceholder() => Container(
      color: const Color(AppColors.primary50),
      child: const Center(
          child:
              Icon(Icons.article_outlined, color: Color(AppColors.primary))));

  Widget _ctaBanner() => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFF1D4ED8), Color(0xFF7C3AED)]),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Join the Library',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('Get access to 10,000+ books and read aloud features.',
              style: TextStyle(color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 16),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: const Color(AppColors.primary)),
            onPressed: () => widget.onTabChange(5),
            child: const Text('Get Started'),
          ),
        ]),
      );

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'Morning';
    if (h < 17) return 'Afternoon';
    return 'Evening';
  }
}
