import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../../services/api_service.dart';
import '../../core/constants.dart';

// class ReaderScreen extends StatefulWidget {
//   final String bookId;
//   const ReaderScreen({super.key, required this.bookId});
//   @override
//   State<ReaderScreen> createState() => _ReaderScreenState();
// }

// final PdfViewerController _pdfController = PdfViewerController();

// class _ReaderScreenState extends State<ReaderScreen> {
//   final _api = ApiService();
//   final _tts = FlutterTts();

//   bool _loading = true;
//   String? _pdfUrl, _bookTitle, _error;
//   int _currentPage = 1, _totalPages = 0;
//   double _progress = 0;
//   bool _hasTextContent = false;
//   bool _ttsEnabled = false, _ttsPlaying = false;
//   double _ttsSpeed = 1.0;
//   int _activeSentence = -1;
//   List<String> _sentences = [];
//   List<Map<String, dynamic>> _bookmarks = [];
//   Map<String, dynamic>? _session;
//   bool _showControls = true;
//   bool _showSettings = false;

//   final _pdfViewerKey = GlobalKey<SfPdfViewerState>();

//   @override
//   void initState() {
//     super.initState();
//     _initReader();
//     _setupTts();
//   }

//   @override
//   void dispose() {
//     _tts.stop();
//     _saveProgress();
//     super.dispose();
//   }

//   Future<void> _initReader() async {
//     try {
//       final res = await _api.get('/reader/${widget.bookId}/init');
//       final d = res.data;
//       setState(() {
//         _pdfUrl = d['pdfUrl'];
//         _bookTitle = d['book']['title'];
//         _totalPages = d['book']['totalPages'] ?? 0;
//         _hasTextContent = d['hasTextContent'] ?? false;
//         _session = d['session'];
//         _bookmarks = List<Map<String, dynamic>>.from(d['bookmarks'] ?? []);
//         _currentPage = d['session']['currentPage'] ?? 1;
//         _progress = (d['session']['progress'] ?? 0).toDouble();
//         _ttsSpeed = (d['session']['ttsSpeed'] ?? 1.0).toDouble();
//         _loading = false;
//       });
//     } catch (e) {
//       setState(() {
//         _error = 'Failed to open book. $e';
//         _loading = false;
//       });
//     }
//   }

//   void _setupTts() async {
//     await _tts.setLanguage('en-US');
//     await _tts.setSpeechRate(_ttsSpeed);
//     _tts.setCompletionHandler(() {
//       final next = _activeSentence + 1;
//       if (next < _sentences.length) {
//         setState(() => _activeSentence = next);
//         _tts.speak(_sentences[next]);
//       } else {
//         setState(() {
//           _ttsPlaying = false;
//           _activeSentence = -1;
//         });
//       }
//     });
//   }

//   Future<void> _loadPageContent(int page) async {
//     if (!_hasTextContent) return;
//     try {
//       final res = await _api.get('/reader/${widget.bookId}/page/$page');
//       setState(() =>
//           _sentences = List<String>.from(res.data['page']['sentences'] ?? []));
//     } catch (_) {
//       setState(() => _sentences = []);
//     }
//   }

//   void _startTts() {
//     if (_sentences.isEmpty) return;
//     setState(() {
//       _ttsPlaying = true;
//       _activeSentence = 0;
//     });
//     _tts.setSpeechRate(_ttsSpeed);
//     _tts.speak(_sentences[0]);
//   }

//   void _pauseTts() {
//     _tts.pause();
//     setState(() => _ttsPlaying = false);
//   }

//   void _stopTts() {
//     _tts.stop();
//     setState(() {
//       _ttsPlaying = false;
//       _activeSentence = -1;
//     });
//   }

//   Future<void> _saveProgress() async {
//     try {
//       await _api.put('/reader/${widget.bookId}/progress', data: {
//         'currentPage': _currentPage,
//         'totalPages': _totalPages,
//         'ttsSpeed': _ttsSpeed,
//         'ttsEnabled': _ttsEnabled,
//       });
//     } catch (_) {}
//   }

//   Future<void> _addBookmark() async {
//     try {
//       final res = await _api.post('/reader/${widget.bookId}/bookmarks', data: {
//         'page': _currentPage,
//         'label': 'Page $_currentPage',
//         'color': 'yellow'
//       });
//       setState(() => _bookmarks.add(res.data['bookmark']));
//       if (mounted)
//         ScaffoldMessenger.of(context)
//             .showSnackBar(const SnackBar(content: Text('Bookmark added!')));
//     } catch (_) {}
//   }

//   bool get _isPageBookmarked =>
//       _bookmarks.any((b) => b['page'] == _currentPage);

//   @override
//   Widget build(BuildContext context) {
//     if (_loading)
//       return const Scaffold(
//           backgroundColor: Color(0xFF0F172A),
//           body: Center(
//               child: Column(mainAxisSize: MainAxisSize.min, children: [
//             CircularProgressIndicator(color: Colors.white),
//             SizedBox(height: 16),
//             Text('Opening reader…', style: TextStyle(color: Colors.white60)),
//           ])));

//     if (_error != null)
//       return Scaffold(
//           backgroundColor: const Color(0xFF0F172A),
//           body: Center(
//               child: Column(children: [
//             const Icon(Icons.error_outline, color: Colors.red, size: 48),
//             const SizedBox(height: 12),
//             Text(_error!,
//                 style: const TextStyle(color: Colors.white70),
//                 textAlign: TextAlign.center),
//             const SizedBox(height: 20),
//             ElevatedButton(
//                 onPressed: () => Navigator.pop(context),
//                 child: const Text('Go Back')),
//           ])));

//     return Scaffold(
//       backgroundColor: const Color(0xFF0F172A),
//       body: GestureDetector(
//         onTap: () => setState(() => _showControls = !_showControls),
//         child: Stack(children: [
//           // ── PDF Viewer ────────────────────────────────────────────────────
//           if (_pdfUrl != null)
//             SfPdfViewer.network(
//               _pdfUrl!,
//               key: _pdfViewerKey,
//               initialPageNumber: _currentPage,
//               onPageChanged: (details) {
//                 setState(() {
//                   _currentPage = details.newPageNumber;
//                   if (_totalPages > 0)
//                     _progress = (_currentPage / _totalPages) * 100;
//                 });
//                 _loadPageContent(_currentPage);
//                 _saveProgress();
//               },
//             )
//           else
//             const Center(
//                 child: Text('No PDF available',
//                     style: TextStyle(color: Colors.white60))),

//           // ── Text content with TTS highlight ──────────────────────────────
//           if (_hasTextContent && _sentences.isNotEmpty && _ttsEnabled)
//             Positioned(
//                 bottom: 120,
//                 left: 0,
//                 right: 0,
//                 child: Container(
//                   margin: const EdgeInsets.all(16),
//                   padding: const EdgeInsets.all(16),
//                   decoration: BoxDecoration(
//                     color: const Color(0xF0FFFBEB),
//                     borderRadius: BorderRadius.circular(16),
//                     boxShadow: [
//                       BoxShadow(
//                           color: Colors.black.withOpacity(0.3), blurRadius: 12)
//                     ],
//                   ),
//                   constraints: const BoxConstraints(maxHeight: 160),
//                   child: SingleChildScrollView(
//                       child: Wrap(
//                           spacing: 4,
//                           runSpacing: 4,
//                           children: _sentences
//                               .asMap()
//                               .entries
//                               .map((e) => Container(
//                                     padding: const EdgeInsets.symmetric(
//                                         horizontal: 4, vertical: 2),
//                                     decoration: BoxDecoration(
//                                       color: e.key == _activeSentence
//                                           ? const Color(0xFFFDE68A)
//                                           : Colors.transparent,
//                                       borderRadius: BorderRadius.circular(4),
//                                     ),
//                                     child: Text('${e.value} ',
//                                         style: TextStyle(
//                                             fontSize: 13,
//                                             height: 1.6,
//                                             color: e.key == _activeSentence
//                                                 ? const Color(0xFF92400E)
//                                                 : const Color(
//                                                     AppColors.textPrimary),
//                                             fontWeight: e.key == _activeSentence
//                                                 ? FontWeight.w700
//                                                 : FontWeight.normal)),
//                                   ))
//                               .toList())),
//                 )),

//           // ── Top bar ───────────────────────────────────────────────────────
//           if (_showControls)
//             Positioned(
//                 top: 0,
//                 left: 0,
//                 right: 0,
//                 child: Container(
//                   padding:
//                       EdgeInsets.only(top: MediaQuery.of(context).padding.top),
//                   decoration: BoxDecoration(
//                       gradient: LinearGradient(
//                           begin: Alignment.topCenter,
//                           end: Alignment.bottomCenter,
//                           colors: [
//                         Colors.black.withOpacity(0.8),
//                         Colors.transparent
//                       ])),
//                   child: Padding(
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
//                     child: Row(children: [
//                       IconButton(
//                           icon:
//                               const Icon(Icons.arrow_back, color: Colors.white),
//                           onPressed: () {
//                             _saveProgress();
//                             Navigator.pop(context);
//                           }),
//                       Expanded(
//                           child: Text(_bookTitle ?? '',
//                               style: const TextStyle(
//                                   color: Colors.white,
//                                   fontWeight: FontWeight.w600,
//                                   fontSize: 15),
//                               maxLines: 1,
//                               overflow: TextOverflow.ellipsis)),
//                       // Progress
//                       Text('${_progress.round()}%',
//                           style: const TextStyle(
//                               color: Colors.white70, fontSize: 12)),
//                       const SizedBox(width: 8),
//                       // Bookmark
//                       IconButton(
//                           icon: Icon(
//                               _isPageBookmarked
//                                   ? Icons.bookmark
//                                   : Icons.bookmark_outline,
//                               color: _isPageBookmarked
//                                   ? const Color(0xFFFBBF24)
//                                   : Colors.white),
//                           onPressed: _isPageBookmarked ? null : _addBookmark),
//                       // Settings
//                       IconButton(
//                           icon: const Icon(Icons.settings_outlined,
//                               color: Colors.white),
//                           onPressed: () =>
//                               setState(() => _showSettings = !_showSettings)),
//                     ]),
//                   ),
//                 )),

//           // ── Settings panel ────────────────────────────────────────────────
//           if (_showSettings && _showControls)
//             Positioned(
//                 top: kToolbarHeight + MediaQuery.of(context).padding.top,
//                 left: 0,
//                 right: 0,
//                 child: Container(
//                   color: const Color(0xF01E293B),
//                   padding:
//                       const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//                   child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         // TTS toggle
//                         Row(
//                             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                             children: [
//                               const Text('Voice Narration',
//                                   style: TextStyle(
//                                       color: Colors.white,
//                                       fontWeight: FontWeight.w600)),
//                               Switch(
//                                   value: _ttsEnabled,
//                                   activeColor: const Color(AppColors.primary),
//                                   onChanged: (v) =>
//                                       setState(() => _ttsEnabled = v)),
//                             ]),
//                         if (_ttsEnabled) ...[
//                           const SizedBox(height: 8),
//                           const Text('Reading Speed',
//                               style: TextStyle(
//                                   color: Colors.white70, fontSize: 13)),
//                           Row(
//                               children: [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
//                                   .map((s) => GestureDetector(
//                                         onTap: () {
//                                           setState(() => _ttsSpeed = s);
//                                           _tts.setSpeechRate(s);
//                                         },
//                                         child: Container(
//                                             margin: const EdgeInsets.only(
//                                                 right: 8, top: 8),
//                                             padding: const EdgeInsets.symmetric(
//                                                 horizontal: 10, vertical: 5),
//                                             decoration: BoxDecoration(
//                                                 color: _ttsSpeed == s
//                                                     ? const Color(
//                                                         AppColors.primary)
//                                                     : Colors.white24,
//                                                 borderRadius:
//                                                     BorderRadius.circular(8)),
//                                             child: Text('${s}x',
//                                                 style: TextStyle(
//                                                     fontSize: 12,
//                                                     color: _ttsSpeed == s
//                                                         ? Colors.white
//                                                         : Colors.white70))),
//                                       ))
//                                   .toList()),
//                         ],
//                       ]),
//                 )),

//           // ── Bottom controls ───────────────────────────────────────────────
//           if (_showControls)
//             Positioned(
//                 bottom: 0,
//                 left: 0,
//                 right: 0,
//                 child: Container(
//                   padding: EdgeInsets.only(
//                       bottom: MediaQuery.of(context).padding.bottom + 8,
//                       left: 16,
//                       right: 16,
//                       top: 12),
//                   decoration: BoxDecoration(
//                       gradient: LinearGradient(
//                           begin: Alignment.bottomCenter,
//                           end: Alignment.topCenter,
//                           colors: [
//                         Colors.black.withOpacity(0.85),
//                         Colors.transparent
//                       ])),
//                   child: Column(mainAxisSize: MainAxisSize.min, children: [
//                     // Progress bar
//                     ClipRRect(
//                         borderRadius: BorderRadius.circular(4),
//                         child: LinearProgressIndicator(
//                             value: _progress / 100,
//                             backgroundColor: Colors.white24,
//                             color: const Color(AppColors.primary),
//                             minHeight: 3)),
//                     const SizedBox(height: 12),
//                     Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           // Page info
//                           Text(
//                               'Page $_currentPage${_totalPages > 0 ? ' / $_totalPages' : ''}',
//                               style: const TextStyle(
//                                   color: Colors.white, fontSize: 13)),
//                           // TTS controls
//                           if (_ttsEnabled && _hasTextContent)
//                             Row(children: [
//                               if (_ttsPlaying)
//                                 IconButton(
//                                     icon: const Icon(Icons.pause_circle,
//                                         color: Colors.white, size: 36),
//                                     onPressed: _pauseTts)
//                               else
//                                 IconButton(
//                                     icon: const Icon(Icons.play_circle,
//                                         color: Colors.white, size: 36),
//                                     onPressed: _startTts),
//                               IconButton(
//                                   icon: const Icon(Icons.stop_circle_outlined,
//                                       color: Colors.white70, size: 28),
//                                   onPressed: _stopTts),
//                             ]),
//                           // Bookmarks
//                           if (_bookmarks.isNotEmpty)
//                             GestureDetector(
//                                 onTap: () => _showBookmarksSheet(),
//                                 child: Row(children: [
//                                   const Icon(Icons.bookmarks_outlined,
//                                       color: Colors.white70, size: 18),
//                                   const SizedBox(width: 4),
//                                   Text('${_bookmarks.length}',
//                                       style: const TextStyle(
//                                           color: Colors.white70, fontSize: 13)),
//                                 ])),
//                         ]),
//                   ]),
//                 )),
//         ]),
//       ),
//     );
//   }

//   void _showBookmarksSheet() => showModalBottomSheet(
//         context: context,
//         backgroundColor: const Color(0xFF1E293B),
//         shape: const RoundedRectangleBorder(
//             borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
//         builder: (_) => Column(mainAxisSize: MainAxisSize.min, children: [
//           const Padding(
//               padding: EdgeInsets.all(16),
//               child: Text('Bookmarks',
//                   style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 16,
//                       fontWeight: FontWeight.w700))),
//           ..._bookmarks
//               .map((b) => ListTile(
//                     leading:
//                         const Icon(Icons.bookmark, color: Color(0xFFFBBF24)),
//                     title: Text('Page ${b['page']}',
//                         style: const TextStyle(color: Colors.white)),
//                     subtitle: b['label'] != null
//                         ? Text(b['label'],
//                             style: const TextStyle(color: Colors.white60))
//                         : null,
//                     onTap: () {
//                       _pdfViewerKey.currentState?.jumpToPage(b['page']);
//                       Navigator.pop(context);
//                     },
//                   ))
//               .toList(),
//           const SizedBox(height: 16),
//         ]),
//       );
// }

// import 'package:flutter/material.dart';
// import 'package:flutter_tts/flutter_tts.dart';
// import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
// import '../../services/api_service.dart';
// import '../../core/constants.dart';

class ReaderScreen extends StatefulWidget {
  final String bookId;
  const ReaderScreen({super.key, required this.bookId});

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderScreenState extends State<ReaderScreen> {
  final _api = ApiService();
  final _tts = FlutterTts();

  // ✅ NEW: Controller (replaces GlobalKey)
  final PdfViewerController _pdfController = PdfViewerController();

  bool _loading = true;
  String? _pdfUrl, _bookTitle, _error;
  int _currentPage = 1, _totalPages = 0;
  double _progress = 0;
  bool _hasTextContent = false;
  bool _ttsEnabled = false, _ttsPlaying = false;
  double _ttsSpeed = 1.0;
  int _activeSentence = -1;
  List<String> _sentences = [];
  List<Map<String, dynamic>> _bookmarks = [];
  Map<String, dynamic>? _session;
  bool _showControls = true;
  bool _showSettings = false;

  @override
  void initState() {
    super.initState();
    _initReader();
    _setupTts();
  }

  @override
  void dispose() {
    _tts.stop();
    _saveProgress();
    super.dispose();
  }

  Future<void> _initReader() async {
    try {
      final res = await _api.get('/reader/${widget.bookId}/init');
      final d = res.data;

      setState(() {
        _pdfUrl = d['pdfUrl'];
        _bookTitle = d['book']['title'];
        _totalPages = d['book']['totalPages'] ?? 0;
        _hasTextContent = d['hasTextContent'] ?? false;
        _session = d['session'];
        _bookmarks = List<Map<String, dynamic>>.from(d['bookmarks'] ?? []);
        _currentPage = d['session']['currentPage'] ?? 1;
        _progress = (d['session']['progress'] ?? 0).toDouble();
        _ttsSpeed = (d['session']['ttsSpeed'] ?? 1.0).toDouble();
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Failed to open book. $e';
        _loading = false;
      });
    }
  }

  void _setupTts() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(_ttsSpeed);

    _tts.setCompletionHandler(() {
      final next = _activeSentence + 1;
      if (next < _sentences.length) {
        setState(() => _activeSentence = next);
        _tts.speak(_sentences[next]);
      } else {
        setState(() {
          _ttsPlaying = false;
          _activeSentence = -1;
        });
      }
    });
  }

  Future<void> _loadPageContent(int page) async {
    if (!_hasTextContent) return;
    try {
      final res = await _api.get('/reader/${widget.bookId}/page/$page');
      setState(() =>
          _sentences = List<String>.from(res.data['page']['sentences'] ?? []));
    } catch (_) {
      setState(() => _sentences = []);
    }
  }

  void _startTts() {
    if (_sentences.isEmpty) return;
    setState(() {
      _ttsPlaying = true;
      _activeSentence = 0;
    });
    _tts.setSpeechRate(_ttsSpeed);
    _tts.speak(_sentences[0]);
  }

  void _pauseTts() {
    _tts.pause();
    setState(() => _ttsPlaying = false);
  }

  void _stopTts() {
    _tts.stop();
    setState(() {
      _ttsPlaying = false;
      _activeSentence = -1;
    });
  }

  Future<void> _saveProgress() async {
    try {
      await _api.put('/reader/${widget.bookId}/progress', data: {
        'currentPage': _currentPage,
        'totalPages': _totalPages,
        'ttsSpeed': _ttsSpeed,
        'ttsEnabled': _ttsEnabled,
      });
    } catch (_) {}
  }

  Future<void> _addBookmark() async {
    try {
      final res = await _api.post(
        '/reader/${widget.bookId}/bookmarks',
        data: {
          'page': _currentPage,
          'label': 'Page $_currentPage',
          'color': 'yellow'
        },
      );

      setState(() => _bookmarks.add(res.data['bookmark']));

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Bookmark added!')),
        );
      }
    } catch (_) {}
  }

  bool get _isPageBookmarked =>
      _bookmarks.any((b) => b['page'] == _currentPage);

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Color(0xFF0F172A),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        body: Center(
            child: Text(_error!, style: const TextStyle(color: Colors.white))),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      body: GestureDetector(
        onTap: () => setState(() => _showControls = !_showControls),
        child: Stack(children: [
          // ✅ FIXED PDF VIEWER
          if (_pdfUrl != null)
            SfPdfViewer.network(
              _pdfUrl!,
              controller: _pdfController,

              // ✅ IMPORTANT FIX
              onDocumentLoaded: (details) async {
                await Future.delayed(const Duration(milliseconds: 100));
                _pdfController.jumpToPage(_currentPage);
              },

              onPageChanged: (details) {
                setState(() {
                  _currentPage = details.newPageNumber;
                  if (_totalPages > 0) {
                    _progress = (_currentPage / _totalPages) * 100;
                  }
                });

                _loadPageContent(_currentPage);
                _saveProgress();
              },
            )
          else
            const Center(
              child: Text('No PDF', style: TextStyle(color: Colors.white)),
            ),

          // TOP BAR
          if (_showControls)
            Positioned(
              top: 40,
              left: 10,
              right: 10,
              child: Row(children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () {
                    _saveProgress();
                    Navigator.pop(context);
                  },
                ),
                Expanded(
                  child: Text(_bookTitle ?? '',
                      style: const TextStyle(color: Colors.white)),
                ),
                Text('${_progress.round()}%',
                    style: const TextStyle(color: Colors.white)),
                IconButton(
                  icon: Icon(
                    _isPageBookmarked ? Icons.bookmark : Icons.bookmark_border,
                    color: Colors.yellow,
                  ),
                  onPressed: _isPageBookmarked ? null : _addBookmark,
                ),
              ]),
            ),

          // BOTTOM CONTROLS
          if (_showControls)
            Positioned(
              bottom: 20,
              left: 20,
              right: 20,
              child: Column(children: [
                LinearProgressIndicator(
                  value: _progress / 100,
                ),
                const SizedBox(height: 10),
                Text(
                  'Page $_currentPage / $_totalPages',
                  style: const TextStyle(color: Colors.white),
                ),
              ]),
            ),
        ]),
      ),
    );
  }

  void _showBookmarksSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => Column(
        children: _bookmarks
            .map((b) => ListTile(
                  title: Text('Page ${b['page']}'),
                  onTap: () {
                    // ✅ FIXED
                    _pdfController.jumpToPage(b['page']);
                    setState(() => _currentPage = b['page']);
                    Navigator.pop(context);
                  },
                ))
            .toList(),
      ),
    );
  }
}
