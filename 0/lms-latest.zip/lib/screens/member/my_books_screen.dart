import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/api_service.dart';
import '../../models/circulation_model.dart';
import '../../core/constants.dart';

class MyBooksScreen extends StatefulWidget {
  const MyBooksScreen({super.key});
  @override
  State<MyBooksScreen> createState() => _MyBooksScreenState();
}

class _MyBooksScreenState extends State<MyBooksScreen> with SingleTickerProviderStateMixin {
  final _api = ApiService();
  List<CirculationModel> _active = [], _history = [];
  bool _loading = true;
  late TabController _tabs;

  @override
  void initState() { super.initState(); _tabs = TabController(length: 2, vsync: this); _load(); }
  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await _api.get('/circulation', params: {'limit': '50'});
      final all = (res.data['circulations'] as List).map((c) => CirculationModel.fromJson(c)).toList();
      setState(() {
        _active  = all.where((c) => ['active','overdue','reserved'].contains(c.status)).toList();
        _history = all.where((c) => ['returned','cancelled','expired'].contains(c.status)).toList();
      });
    } catch (_) {}
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Books'), bottom: TabBar(
        controller: _tabs,
        tabs: [
          Tab(text: 'Active (${_active.length})'),
          Tab(text: 'History (${_history.length})'),
        ],
        labelColor: const Color(AppColors.primary),
        unselectedLabelColor: const Color(AppColors.textSecondary),
        indicatorColor: const Color(AppColors.primary),
      )),
      body: _loading
        ? const Center(child: CircularProgressIndicator())
        : TabBarView(controller: _tabs, children: [
            _buildList(_active, isActive: true),
            _buildList(_history, isActive: false),
          ]),
    );
  }

  Widget _buildList(List<CirculationModel> items, {required bool isActive}) {
    if (items.isEmpty) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.menu_book_outlined, size: 64, color: Color(AppColors.textSecondary)),
      const SizedBox(height: 12),
      Text(isActive ? 'No active borrows' : 'No history yet',
        style: const TextStyle(color: Color(AppColors.textSecondary))),
    ]));
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) => _circulationCard(items[i]),
      ),
    );
  }

  Widget _circulationCard(CirculationModel c) {
    final statusColor = <String, Color>{
      'active': const Color(AppColors.success), 'overdue': const Color(AppColors.error),
      'reserved': const Color(AppColors.warning), 'returned': const Color(AppColors.textSecondary),
      'cancelled': const Color(AppColors.textSecondary), 'expired': const Color(AppColors.textSecondary),
    }[c.status] ?? const Color(AppColors.textSecondary);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: c.isOverdue ? const Color(AppColors.error) : const Color(AppColors.border)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 6)]),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 48, height: 64, decoration: BoxDecoration(
          color: const Color(AppColors.primary50), borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.book, color: Color(AppColors.primary))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(c.bookTitle ?? 'Unknown Book', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15), maxLines: 2, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          Row(children: [
            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: statusColor.withOpacity(0.12), borderRadius: BorderRadius.circular(6)),
              child: Text(c.status.toUpperCase(), style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: statusColor))),
            const SizedBox(width: 8),
            Text(c.type.toUpperCase(), style: const TextStyle(fontSize: 10, color: Color(AppColors.textSecondary))),
          ]),
          const SizedBox(height: 6),
          if (c.issueDate != null)
            _metaRow(Icons.calendar_today_outlined, 'Issued: ${DateFormat('MMM d, yyyy').format(c.issueDate!)}'),
          if (c.dueDate != null)
            _metaRow(c.isOverdue ? Icons.warning_amber_outlined : Icons.event_outlined,
              'Due: ${DateFormat('MMM d, yyyy').format(c.dueDate!)}',
              color: c.isOverdue ? const Color(AppColors.error) : null),
          if (c.fine > 0)
            _metaRow(Icons.attach_money_outlined, 'Fine: \$${c.fine.toStringAsFixed(2)}${c.finePaid ? ' (Paid)' : ''}',
              color: c.finePaid ? const Color(AppColors.success) : const Color(AppColors.error)),
        ])),
      ]),
    );
  }

  Widget _metaRow(IconData icon, String text, {Color? color}) => Padding(
    padding: const EdgeInsets.only(top: 3),
    child: Row(children: [
      Icon(icon, size: 13, color: color ?? const Color(AppColors.textSecondary)),
      const SizedBox(width: 4),
      Text(text, style: TextStyle(fontSize: 12, color: color ?? const Color(AppColors.textSecondary))),
    ]),
  );
}
