import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/api_service.dart';
import '../../core/constants.dart';

class MyDownloadsScreen extends StatefulWidget {
  final Function(String) onReadTap;
  const MyDownloadsScreen({super.key, required this.onReadTap});
  @override
  State<MyDownloadsScreen> createState() => _MyDownloadsScreenState();
}

class _MyDownloadsScreenState extends State<MyDownloadsScreen> {
  final _api = ApiService();
  List<dynamic> _purchases = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await _api.get('/digital/my-purchases');
      setState(() => _purchases = res.data['purchases'] ?? []);
    } catch (_) {}
    setState(() => _loading = false);
  }

  Future<void> _download(String bookId) async {
    try {
      final res = await _api.get('/digital/$bookId/download');
      final url = res.data['url'];
      if (url != null) await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Download failed')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Downloads')),
      body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _purchases.isEmpty
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.download_outlined, size: 64, color: Color(AppColors.textSecondary)),
              SizedBox(height: 12),
              Text('No downloads yet', style: TextStyle(color: Color(AppColors.textSecondary))),
            ]))
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: _purchases.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final p = _purchases[i];
                  final book = p['book'];
                  final bookId = book is Map ? (book['_id'] ?? '') : (p['book'] ?? '');
                  final title = book is Map ? (book['title'] ?? 'Unknown') : 'Unknown Book';
                  final format = book is Map ? (book['ebookFormat'] ?? 'pdf') : 'pdf';
                  final progress = (p['readingProgress'] ?? 0).toDouble();

                  return Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: const Color(AppColors.border))),
                    child: Row(children: [
                      Container(width: 50, height: 68, decoration: BoxDecoration(
                        color: const Color(0xFFEDE9FE), borderRadius: BorderRadius.circular(8)),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          const Icon(Icons.picture_as_pdf, color: Color(0xFF7C3AED), size: 22),
                          Text(format.toUpperCase(), style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w800, color: Color(0xFF7C3AED))),
                        ])),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14), maxLines: 2, overflow: TextOverflow.ellipsis),
                        const SizedBox(height: 4),
                        if (progress > 0) ...[
                          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                            Text('${progress.round()}% read', style: const TextStyle(fontSize: 11, color: Color(AppColors.textSecondary))),
                          ]),
                          const SizedBox(height: 4),
                          ClipRRect(borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(value: progress / 100,
                              backgroundColor: const Color(AppColors.primary100),
                              color: const Color(AppColors.primary), minHeight: 4)),
                          const SizedBox(height: 6),
                        ],
                        Row(children: [
                          Expanded(child: OutlinedButton.icon(
                            onPressed: () => widget.onReadTap(bookId),
                            icon: const Icon(Icons.menu_book_outlined, size: 14),
                            label: const Text('Read', style: TextStyle(fontSize: 12)),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(AppColors.primary),
                              side: const BorderSide(color: Color(AppColors.primary)),
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                          )),
                          const SizedBox(width: 8),
                          Expanded(child: ElevatedButton.icon(
                            onPressed: () => _download(bookId),
                            icon: const Icon(Icons.download_outlined, size: 14),
                            label: const Text('Download', style: TextStyle(fontSize: 12)),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                          )),
                        ]),
                      ])),
                    ]),
                  );
                },
              ),
            ),
    );
  }
}
