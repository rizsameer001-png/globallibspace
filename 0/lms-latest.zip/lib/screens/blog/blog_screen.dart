import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:intl/intl.dart';
import '../../services/api_service.dart';
import '../../models/blog_model.dart';
import '../../core/constants.dart';

class BlogScreen extends StatefulWidget {
  final Function(String) onPostTap;
  const BlogScreen({super.key, required this.onPostTap});
  @override
  State<BlogScreen> createState() => _BlogScreenState();
}

class _BlogScreenState extends State<BlogScreen> {
  final _api = ApiService();
  List<BlogPost> _posts = [];
  List<Map<String, dynamic>> _categories = [];
  bool _loading = false, _hasMore = true;
  int _page = 1;
  String _category = '', _search = '';
  bool _isGrid = true;
  final _searchCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadPosts(refresh: true);
    _scrollCtrl.addListener(() {
      if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 200
          && _hasMore && !_loading) _loadPosts();
    });
  }

  @override
  void dispose() { _searchCtrl.dispose(); _scrollCtrl.dispose(); super.dispose(); }

  Future<void> _loadPosts({bool refresh = false}) async {
    if (refresh) { _page = 1; _posts = []; _hasMore = true; }
    if (_loading || !_hasMore) return;
    setState(() => _loading = true);
    try {
      final params = <String, dynamic>{'page': _page, 'limit': 9};
      if (_category.isNotEmpty) params['category'] = _category;
      if (_search.isNotEmpty) params['search'] = _search;
      final res = await _api.get('/blogs', params: params);
      final p = res.data['pagination'];
      final newPosts = (res.data['posts'] as List).map((b) => BlogPost.fromJson(b)).toList();
      if (refresh && res.data['categories'] != null) {
        _categories = List<Map<String, dynamic>>.from(res.data['categories']);
      }
      setState(() {
        _posts.addAll(newPosts);
        _page++;
        _hasMore = _page <= (p['pages'] ?? 1);
      });
    } catch (_) {}
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Blog'),
        actions: [
          IconButton(
            icon: Icon(_isGrid ? Icons.list : Icons.grid_view),
            onPressed: () => setState(() => _isGrid = !_isGrid),
          ),
        ],
      ),
      body: Column(children: [
        // Search
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: TextField(
            controller: _searchCtrl,
            onSubmitted: (v) { _search = v; _loadPosts(refresh: true); },
            decoration: InputDecoration(
              hintText: 'Search posts…',
              prefixIcon: const Icon(Icons.search, size: 20),
              suffixIcon: _searchCtrl.text.isNotEmpty
                ? IconButton(icon: const Icon(Icons.clear, size: 18),
                    onPressed: () { _searchCtrl.clear(); _search = ''; _loadPosts(refresh: true); })
                : null,
            ),
          ),
        ),
        // Category chips
        if (_categories.isNotEmpty) Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: SizedBox(height: 36, child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _categories.length + 1,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, i) {
              if (i == 0) return _chip('All', _category.isEmpty);
              final cat = _categories[i - 1];
              return _chip('${cat['_id']} (${cat['count']})', _category == cat['_id']);
            },
          )),
        ),
        Expanded(child: RefreshIndicator(
          onRefresh: () => _loadPosts(refresh: true),
          child: _posts.isEmpty && _loading
            ? const Center(child: CircularProgressIndicator())
            : _posts.isEmpty
              ? const Center(child: Text('No posts found', style: TextStyle(color: Color(AppColors.textSecondary))))
              : _isGrid ? _buildGrid() : _buildList(),
        )),
      ]),
    );
  }

  Widget _buildGrid() => GridView.builder(
    controller: _scrollCtrl,
    padding: const EdgeInsets.all(16),
    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.7),
    itemCount: _posts.length + (_loading ? 1 : 0),
    itemBuilder: (_, i) {
      if (i == _posts.length) return const Center(child: CircularProgressIndicator());
      return _gridCard(_posts[i]);
    },
  );

  Widget _buildList() => ListView.separated(
    controller: _scrollCtrl,
    padding: const EdgeInsets.all(16),
    itemCount: _posts.length + (_loading ? 1 : 0),
    separatorBuilder: (_, __) => const SizedBox(height: 12),
    itemBuilder: (_, i) {
      if (i == _posts.length) return const Center(child: CircularProgressIndicator());
      return _listCard(_posts[i]);
    },
  );

  Widget _gridCard(BlogPost post) => GestureDetector(
    onTap: () => widget.onPostTap(post.postId),
    child: Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(AppColors.border)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
          child: AspectRatio(aspectRatio: 16 / 9,
            child: post.coverImage != null
              ? CachedNetworkImage(imageUrl: post.coverImage!, fit: BoxFit.cover,
                  errorWidget: (_, __, ___) => _placeholder())
              : _placeholder())),
        Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (post.category != null) _categoryBadge(post.category!),
          const SizedBox(height: 4),
          Text(post.title, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('${post.readTime} min', style: const TextStyle(fontSize: 10, color: Color(AppColors.textSecondary))),
        ])),
      ]),
    ),
  );

  Widget _listCard(BlogPost post) => GestureDetector(
    onTap: () => widget.onPostTap(post.postId),
    child: Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(AppColors.border))),
      child: Row(children: [
        ClipRRect(borderRadius: const BorderRadius.horizontal(left: Radius.circular(14)),
          child: SizedBox(width: 100, height: 90,
            child: post.coverImage != null
              ? CachedNetworkImage(imageUrl: post.coverImage!, fit: BoxFit.cover,
                  errorWidget: (_, __, ___) => _placeholder())
              : _placeholder())),
        Expanded(child: Padding(padding: const EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (post.category != null) _categoryBadge(post.category!),
          const SizedBox(height: 4),
          Text(post.title, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Row(children: [
            Text(post.authorName ?? 'Library', style: const TextStyle(fontSize: 11, color: Color(AppColors.textSecondary))),
            const Text(' · ', style: TextStyle(color: Color(AppColors.textSecondary))),
            Text('${post.readTime} min', style: const TextStyle(fontSize: 11, color: Color(AppColors.textSecondary))),
          ]),
        ]))),
      ]),
    ),
  );

  Widget _chip(String label, bool selected) => GestureDetector(
    onTap: () {
      setState(() => _category = selected ? '' : label.split(' ').first);
      _loadPosts(refresh: true);
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? const Color(AppColors.primary) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: selected ? const Color(AppColors.primary) : const Color(AppColors.border))),
      child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
        color: selected ? Colors.white : const Color(AppColors.textSecondary))),
    ),
  );

  Widget _categoryBadge(String cat) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
    decoration: BoxDecoration(color: const Color(AppColors.primary50), borderRadius: BorderRadius.circular(6)),
    child: Text(cat, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Color(AppColors.primary))));

  Widget _placeholder() => Container(color: const Color(AppColors.primary50),
    child: const Center(child: Icon(Icons.article_outlined, color: Color(AppColors.primary))));
}
