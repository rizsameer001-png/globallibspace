import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:intl/intl.dart';
import '../../services/api_service.dart';
import '../../models/blog_model.dart';
import '../../core/constants.dart';

class BlogPostScreen extends StatefulWidget {
  final String slug;
  final Function(String) onPostTap;
  const BlogPostScreen({super.key, required this.slug, required this.onPostTap});
  @override
  State<BlogPostScreen> createState() => _BlogPostScreenState();
}

class _BlogPostScreenState extends State<BlogPostScreen> {
  final _api = ApiService();
  BlogPost? _post;
  List<BlogPost> _similar = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _loadPost(); }

  Future<void> _loadPost() async {
    try {
      final res = await _api.get('/blogs/${widget.slug}');
      setState(() {
        _post    = BlogPost.fromJson(res.data['post']);
        _similar = (res.data['similar'] as List).map((p) => BlogPost.fromJson(p)).toList();
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_post == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Post not found')));
    final post = _post!;

    return Scaffold(
      body: CustomScrollView(slivers: [
        // Cover
        SliverAppBar(
          expandedHeight: post.coverImage != null ? 240 : 0,
          pinned: true,
          backgroundColor: const Color(AppColors.primary),
          flexibleSpace: post.coverImage != null
            ? FlexibleSpaceBar(background: CachedNetworkImage(
                imageUrl: post.coverImage!, fit: BoxFit.cover,
                errorWidget: (_, __, ___) => Container(color: const Color(AppColors.primary100))))
            : null,
        ),

        SliverPadding(
          padding: const EdgeInsets.all(20),
          sliver: SliverList(delegate: SliverChildListDelegate([
            // Category + tags
            Wrap(spacing: 8, runSpacing: 6, children: [
              if (post.category != null) _badge(post.category!, const Color(AppColors.primary50), const Color(AppColors.primary)),
              if (post.subCategory != null && post.subCategory!.isNotEmpty)
                _badge(post.subCategory!, const Color(0xFFEDE9FE), const Color(0xFF7C3AED)),
              ...post.tags.take(3).map((t) => _badge('#$t', const Color(AppColors.surface), const Color(AppColors.textSecondary))),
            ]),
            const SizedBox(height: 12),

            // Title
            Text(post.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, height: 1.3)),
            const SizedBox(height: 12),

            // Meta
            Row(children: [
              const Icon(Icons.person_outline, size: 15, color: Color(AppColors.textSecondary)),
              const SizedBox(width: 4),
              Text(post.authorName ?? 'Library', style: const TextStyle(fontSize: 13, color: Color(AppColors.textSecondary))),
              const SizedBox(width: 12),
              const Icon(Icons.schedule_outlined, size: 15, color: Color(AppColors.textSecondary)),
              const SizedBox(width: 4),
              Text('${post.readTime} min read', style: const TextStyle(fontSize: 13, color: Color(AppColors.textSecondary))),
              const SizedBox(width: 12),
              const Icon(Icons.visibility_outlined, size: 15, color: Color(AppColors.textSecondary)),
              const SizedBox(width: 4),
              Text('${post.views}', style: const TextStyle(fontSize: 13, color: Color(AppColors.textSecondary))),
            ]),
            const Divider(height: 28),

            // Content
            if (post.content != null && post.content!.isNotEmpty)
              Html(
                data: post.content!,
                style: {
                  "body": Style(fontSize: FontSize(15), lineHeight: const LineHeight(1.75), color: const Color(AppColors.textPrimary)),
                  "h2": Style(fontSize: FontSize(20), fontWeight: FontWeight.w700, margin: Margins.only(top: 20, bottom: 8)),
                  "h3": Style(fontSize: FontSize(17), fontWeight: FontWeight.w600, margin: Margins.only(top: 16, bottom: 6)),
                  "p": Style(margin: Margins.only(bottom: 12)),
                  "blockquote": Style(
                    border: const Border(left: BorderSide(color: Color(AppColors.primary), width: 4)),
                    padding: HtmlPaddings.only(left: 16),
                    fontStyle: FontStyle.italic,
                    color: const Color(AppColors.textSecondary),
                  ),
                  "a": Style(color: const Color(AppColors.primary), textDecoration: TextDecoration.underline),
                },
              )
            else if (post.excerpt != null)
              Text(post.excerpt!, style: const TextStyle(fontSize: 15, height: 1.7, color: Color(AppColors.textSecondary))),

            const SizedBox(height: 28),

            // Similar posts
            if (_similar.isNotEmpty) ...[
              const Text('Related Posts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 14),
              ..._similar.map((p) => GestureDetector(
                onTap: () => widget.onPostTap(p.postId),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(AppColors.border))),
                  child: Row(children: [
                    if (p.coverImage != null) ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: CachedNetworkImage(imageUrl: p.coverImage!, width: 70, height: 60, fit: BoxFit.cover)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(p.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text('${p.readTime} min · ${p.category ?? ''}',
                        style: const TextStyle(fontSize: 11, color: Color(AppColors.textSecondary))),
                    ])),
                    const Icon(Icons.arrow_forward_ios, size: 14, color: Color(AppColors.textSecondary)),
                  ]),
                ),
              )),
            ],
            const SizedBox(height: 20),
          ])),
        ),
      ]),
    );
  }

  Widget _badge(String text, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
    child: Text(text, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg)));
}
