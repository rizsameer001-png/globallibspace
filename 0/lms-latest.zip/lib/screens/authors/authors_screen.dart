import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../services/api_service.dart';
import '../../models/author_model.dart';
import '../../core/constants.dart';

class AuthorsScreen extends StatefulWidget {
  final Function(String) onAuthorTap;
  const AuthorsScreen({super.key, required this.onAuthorTap});
  @override
  State<AuthorsScreen> createState() => _AuthorsScreenState();
}

class _AuthorsScreenState extends State<AuthorsScreen> {
  final _api = ApiService();
  List<AuthorModel> _authors = [];
  List<String> _letters = [];
  String _selectedLetter = '';
  String _search = '';
  bool _loading = false;
  int _page = 1;
  bool _hasMore = true;
  final _searchCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    _loadLetters();
    _loadAuthors(refresh: true);
    _scrollCtrl.addListener(() {
      if (_scrollCtrl.position.pixels >= _scrollCtrl.position.maxScrollExtent - 200 && _hasMore && !_loading)
        _loadAuthors();
    });
  }

  @override
  void dispose() { _searchCtrl.dispose(); _scrollCtrl.dispose(); super.dispose(); }

  Future<void> _loadLetters() async {
    try {
      final res = await _api.get('/authors/letters');
      setState(() => _letters = List<String>.from(res.data['letters'] ?? []));
    } catch (_) {}
  }

  Future<void> _loadAuthors({bool refresh = false}) async {
    if (refresh) { _page = 1; _authors = []; _hasMore = true; }
    if (_loading || !_hasMore) return;
    setState(() => _loading = true);
    try {
      final params = <String, dynamic>{'page': _page, 'limit': 24};
      if (_search.isNotEmpty) params['search'] = _search;
      if (_selectedLetter.isNotEmpty) params['letter'] = _selectedLetter;
      final res = await _api.get('/authors', params: params);
      final p = res.data['pagination'];
      final newList = (res.data['authors'] as List).map((a) => AuthorModel.fromJson(a)).toList();
      setState(() {
        _authors.addAll(newList);
        _page++;
        _hasMore = _page <= (p['pages'] ?? 1);
      });
    } catch (_) {}
    setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Authors')),
      body: Column(children: [
        // Search
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: TextField(
            controller: _searchCtrl,
            onChanged: (v) { _search = v; },
            onSubmitted: (_) => _loadAuthors(refresh: true),
            decoration: InputDecoration(
              hintText: 'Search authors…',
              prefixIcon: const Icon(Icons.search, size: 20),
              suffixIcon: _searchCtrl.text.isNotEmpty
                ? IconButton(icon: const Icon(Icons.clear, size: 18),
                    onPressed: () { _searchCtrl.clear(); _search = ''; _loadAuthors(refresh: true); })
                : null),
          ),
        ),
        // A-Z nav
        if (_letters.isNotEmpty) Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: SizedBox(height: 36, child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _letters.length + 1,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (_, i) {
              if (i == 0) {
                return _letterChip('All', _selectedLetter.isEmpty);
              }
              return _letterChip(_letters[i - 1], _selectedLetter == _letters[i - 1]);
            },
          )),
        ),
        // Grid
        Expanded(child: _authors.isEmpty && _loading
          ? const Center(child: CircularProgressIndicator())
          : _authors.isEmpty
            ? const Center(child: Text('No authors found', style: TextStyle(color: Color(AppColors.textSecondary))))
            : GridView.builder(
                controller: _scrollCtrl,
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.75),
                itemCount: _authors.length + (_loading ? 1 : 0),
                itemBuilder: (_, i) {
                  if (i == _authors.length) return const Center(child: CircularProgressIndicator());
                  return _authorCard(_authors[i]);
                },
              )),
      ]),
    );
  }

  Widget _letterChip(String label, bool selected) => GestureDetector(
    onTap: () {
      setState(() => _selectedLetter = label == 'All' ? '' : label);
      _loadAuthors(refresh: true);
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? const Color(AppColors.primary) : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: selected ? const Color(AppColors.primary) : const Color(AppColors.border))),
      child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
        color: selected ? Colors.white : const Color(AppColors.textSecondary))),
    ),
  );

  Widget _authorCard(AuthorModel a) => GestureDetector(
    onTap: () => widget.onAuthorTap(a.profileId),
    child: Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(AppColors.border)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6)]),
      child: Column(children: [
        // Avatar
        ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          child: AspectRatio(aspectRatio: 1,
            child: a.avatar != null
              ? CachedNetworkImage(imageUrl: a.avatar!, fit: BoxFit.cover, alignment: Alignment.topCenter,
                  errorWidget: (_, __, ___) => _avatarPlaceholder(a))
              : _avatarPlaceholder(a))),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(a.name, maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
            if (a.nationality != null) Text(a.nationality!, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: Color(AppColors.textSecondary))),
            if (a.genres.isNotEmpty) const SizedBox(height: 6),
            if (a.genres.isNotEmpty) Wrap(spacing: 4, children: a.genres.take(2).map((g) =>
              Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(color: const Color(AppColors.primary50), borderRadius: BorderRadius.circular(6)),
                child: Text(g, style: const TextStyle(fontSize: 9, color: Color(AppColors.primary), fontWeight: FontWeight.w600)))
              ).toList()),
          ]),
        ),
      ]),
    ),
  );

  Widget _avatarPlaceholder(AuthorModel a) => Container(color: const Color(AppColors.primary50),
    child: Center(child: Text(a.name[0].toUpperCase(),
      style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Color(AppColors.primary)))));
}
