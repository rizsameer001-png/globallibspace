import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../services/api_service.dart';
import '../../models/author_model.dart';
import '../../models/book_model.dart';
import '../../widgets/common/book_card.dart';
import '../../core/constants.dart';

class AuthorProfileScreen extends StatefulWidget {
  final String slug;
  final Function(String) onBookTap;
  const AuthorProfileScreen({super.key, required this.slug, required this.onBookTap});
  @override
  State<AuthorProfileScreen> createState() => _AuthorProfileScreenState();
}

class _AuthorProfileScreenState extends State<AuthorProfileScreen> with SingleTickerProviderStateMixin {
  final _api = ApiService();
  AuthorModel? _author;
  List<BookModel> _books = [];
  bool _loading = true;
  late TabController _tabs;
  bool _bioExpanded = false;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
    _loadProfile();
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _loadProfile() async {
    try {
      final res = await _api.get('/authors/${widget.slug}');
      setState(() {
        _author = AuthorModel.fromJson(res.data['author']);
        _books  = (res.data['books'] as List).map((b) => BookModel.fromJson(b)).toList();
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_author == null) return Scaffold(appBar: AppBar(), body: const Center(child: Text('Author not found')));
    final a = _author!;

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (_, __) => [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: const Color(AppColors.primary900),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(fit: StackFit.expand, children: [
                if (a.avatar != null)
                  CachedNetworkImage(imageUrl: a.avatar!, fit: BoxFit.cover, alignment: Alignment.topCenter)
                else Container(color: const Color(AppColors.primary700)),
                Container(decoration: const BoxDecoration(gradient: LinearGradient(
                  begin: Alignment.topCenter, end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xCC000000)]))),
                Positioned(bottom: 16, left: 16, right: 16,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(a.name, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                    if (a.nationality != null || a.birthYear != null)
                      Text('${a.nationality ?? ''} ${a.lifespan}'.trim(),
                        style: const TextStyle(color: Colors.white70, fontSize: 13)),
                    if (a.isFeatured)
                      Container(margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(color: const Color(0xFFFBBF24), borderRadius: BorderRadius.circular(8)),
                        child: const Text('★ Featured', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF92400E)))),
                  ])),
              ]),
            ),
          ),
          SliverPersistentHeader(pinned: true, delegate: _TabBarDelegate(TabBar(
            controller: _tabs,
            labelColor: const Color(AppColors.primary),
            unselectedLabelColor: const Color(AppColors.textSecondary),
            indicatorColor: const Color(AppColors.primary),
            isScrollable: true,
            tabs: [
              Tab(text: 'Books (${_books.length})'),
              Tab(text: 'Bio'),
              Tab(text: 'Videos (${a.youtubeLinks?.length ?? 0})'),
              Tab(text: 'Timeline'),
            ],
          ))),
        ],
        body: TabBarView(controller: _tabs, children: [
          // Books tab
          _books.isEmpty
            ? const Center(child: Text('No books available'))
            : GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.55),
                itemCount: _books.length,
                itemBuilder: (_, i) => BookCard(book: _books[i], onTap: () => widget.onBookTap(_books[i].id))),

          // Bio tab
          SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Genres
            if (a.genres.isNotEmpty) ...[
              const Text('Genres', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 6, children: a.genres.map((g) =>
                Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(color: const Color(AppColors.primary50), borderRadius: BorderRadius.circular(20)),
                  child: Text(g, style: const TextStyle(fontSize: 13, color: Color(AppColors.primary), fontWeight: FontWeight.w600)))
                ).toList()),
              const SizedBox(height: 16),
            ],
            // Bio
            if (a.fullBio != null || a.shortBio != null) ...[
              const Text('Biography', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(a.fullBio ?? a.shortBio ?? '',
                maxLines: _bioExpanded ? null : 6,
                overflow: _bioExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 14, height: 1.7, color: Color(AppColors.textSecondary))),
              GestureDetector(onTap: () => setState(() => _bioExpanded = !_bioExpanded),
                child: Text(_bioExpanded ? 'Show less' : 'Read more',
                  style: const TextStyle(color: Color(AppColors.primary), fontWeight: FontWeight.w600, fontSize: 13))),
            ],
          ])),

          // Videos tab
          a.youtubeLinks.isEmpty
            ? const Center(child: Text('No videos available'))
            : ListView(padding: const EdgeInsets.all(16),
                children: a.youtubeLinks.map((v) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.play_circle_outline, color: Colors.red, size: 36),
                    title: Text(v['title'] ?? 'Video', style: const TextStyle(fontWeight: FontWeight.w600)),
                    onTap: () => launchUrl(Uri.parse(v['url'] ?? '')),
                  ))).toList()),

          // Timeline tab
          a.timeline.isEmpty
            ? const Center(child: Text('No timeline available'))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: a.timeline.length,
                itemBuilder: (_, i) {
                  final e = a.timeline[i];
                  return IntrinsicHeight(child: Row(children: [
                    SizedBox(width: 48, child: Column(children: [
                      Container(width: 12, height: 12, decoration: const BoxDecoration(color: Color(AppColors.primary), shape: BoxShape.circle)),
                      Expanded(child: Container(width: 2, color: const Color(AppColors.primary100))),
                    ])),
                    Expanded(child: Container(margin: const EdgeInsets.only(bottom: 16),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(AppColors.border))),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${e['year']}', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Color(AppColors.primary))),
                        const SizedBox(height: 2),
                        Text(e['event'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                        if (e['description'] != null) ...[
                          const SizedBox(height: 4),
                          Text(e['description'], style: const TextStyle(fontSize: 12, color: Color(AppColors.textSecondary))),
                        ],
                      ]))),
                  ]));
                }),
        ]),
      ),
    );
  }
}

// ignore: must_be_immutable
class _TabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar tabBar;
  _TabBarDelegate(this.tabBar);
  @override double get minExtent => tabBar.preferredSize.height;
  @override double get maxExtent => tabBar.preferredSize.height;
  @override Widget build(_, __, ___) => Container(color: Colors.white, child: tabBar);
  @override bool shouldRebuild(_) => false;
}


