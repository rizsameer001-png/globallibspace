import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants.dart';
import '../models/user_model.dart';
import 'api_service.dart';

class AuthService {
  final _api = ApiService();

  Future<UserModel> login(String email, String password) async {
    final res = await _api.post('/auth/login', data: {'email': email, 'password': password});
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.tokenKey, res.data['token']);
    final user = UserModel.fromJson(res.data['user']);
    await prefs.setString(AppConstants.userKey, jsonEncode(res.data['user']));
    return user;
  }

  Future<UserModel> register(String name, String email, String password) async {
    final res = await _api.post('/auth/register', data: {
      'name': name, 'email': email, 'password': password,
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(AppConstants.tokenKey, res.data['token']);
    final user = UserModel.fromJson(res.data['user']);
    await prefs.setString(AppConstants.userKey, jsonEncode(res.data['user']));
    return user;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(AppConstants.tokenKey);
    await prefs.remove(AppConstants.userKey);
  }

  Future<UserModel?> getStoredUser() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(AppConstants.userKey);
    if (data == null) return null;
    return UserModel.fromJson(jsonDecode(data));
  }

  Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(AppConstants.tokenKey) != null;
  }
}
