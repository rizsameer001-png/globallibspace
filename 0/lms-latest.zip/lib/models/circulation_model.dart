class CirculationModel {
  final String id, status, type;
  final String? bookTitle, bookCover, memberName;
  final DateTime? issueDate, dueDate, returnDate;
  final double fine;
  final bool finePaid;

  CirculationModel({required this.id, required this.status, required this.type,
    this.bookTitle, this.bookCover, this.memberName,
    this.issueDate, this.dueDate, this.returnDate,
    this.fine = 0, this.finePaid = false});

  factory CirculationModel.fromJson(Map<String, dynamic> j) => CirculationModel(
    id: j['_id'] ?? '', status: j['status'] ?? '', type: j['type'] ?? '',
    bookTitle: j['book'] is Map ? j['book']['title'] : null,
    bookCover: j['book'] is Map ? j['book']['coverImage'] : null,
    memberName: j['member'] is Map ? j['member']['name'] : null,
    issueDate: j['issueDate'] != null ? DateTime.tryParse(j['issueDate']) : null,
    dueDate: j['dueDate'] != null ? DateTime.tryParse(j['dueDate']) : null,
    returnDate: j['returnDate'] != null ? DateTime.tryParse(j['returnDate']) : null,
    fine: (j['fine'] ?? 0).toDouble(), finePaid: j['finePaid'] ?? false,
  );

  bool get isOverdue => dueDate != null && DateTime.now().isAfter(dueDate!) && status == 'active';
}
