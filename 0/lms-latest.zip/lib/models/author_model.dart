class AuthorModel {
  final String id, name;
  final String? slug, avatar, nationality, shortBio, fullBio;
  final List<String> genres, languages;
  final int? birthYear, deathYear, bookCount;
  final bool isFeatured;
  final List<Map<String, dynamic>> youtubeLinks, audioLinks, articles, timeline;

  AuthorModel({
    required this.id, required this.name, this.slug, this.avatar,
    this.nationality, this.shortBio, this.fullBio,
    this.genres = const [], this.languages = const [],
    this.birthYear, this.deathYear, this.bookCount,
    this.isFeatured = false,
    this.youtubeLinks = const [], this.audioLinks = const [],
    this.articles = const [], this.timeline = const [],
  });

  factory AuthorModel.fromJson(Map<String, dynamic> j) => AuthorModel(
    id: j['_id'] ?? '', name: j['name'] ?? '',
    slug: j['slug'], avatar: j['avatar'], nationality: j['nationality'],
    shortBio: j['shortBio'], fullBio: j['fullBio'],
    genres:    List<String>.from(j['genres'] ?? []),
    languages: List<String>.from(j['languages'] ?? []),
    birthYear: j['birthYear'], deathYear: j['deathYear'],
    bookCount: j['bookCount'], isFeatured: j['isFeatured'] ?? false,
    youtubeLinks: List<Map<String, dynamic>>.from(j['youtubeLinks'] ?? []),
    audioLinks:   List<Map<String, dynamic>>.from(j['audioLinks']   ?? []),
    articles:     List<Map<String, dynamic>>.from(j['articles']     ?? []),
    timeline:     List<Map<String, dynamic>>.from(j['timeline']     ?? []),
  );

  String get profileId => slug ?? id;

  String get lifespan {
    if (birthYear == null) return '';
    return deathYear != null ? '$birthYear – $deathYear' : 'b. $birthYear';
  }
}
