class BookModel {
  final String id, title;
  final List<String> authorNames;
  final List<String> categoryNames;
  final String? coverImage, isbn, description, language, bookType, ebookFormat;
  final int totalCopies, availableCopies;
  final bool readingEnabled, downloadEnabled, isDigitalSale, isEbook;
  final double digitalPrice;
  final String? digitalPriceDisplay;
  final int? publicationYear, pages, readingPageCount;

  BookModel({
    required this.id, required this.title,
    this.authorNames = const [], this.categoryNames = const [],
    this.coverImage, this.isbn, this.description, this.language,
    this.bookType = 'physical', this.ebookFormat,
    this.totalCopies = 0, this.availableCopies = 0,
    this.readingEnabled = false, this.downloadEnabled = false,
    this.isDigitalSale = false, this.isEbook = false,
    this.digitalPrice = 0, this.digitalPriceDisplay,
    this.publicationYear, this.pages, this.readingPageCount,
  });

  factory BookModel.fromJson(Map<String, dynamic> j) => BookModel(
    id: j['_id'] ?? '',
    title: j['title'] ?? '',
    authorNames: _extractNames(j['authors']),
    categoryNames: _extractNames(j['categories']),
    coverImage: j['coverImage'],
    isbn: j['isbn'],
    description: j['description'],
    language: j['language'],
    bookType: j['bookType'] ?? 'physical',
    ebookFormat: j['ebookFormat'],
    totalCopies: j['totalCopies'] ?? 0,
    availableCopies: j['availableCopies'] ?? 0,
    readingEnabled: j['readingEnabled'] ?? false,
    downloadEnabled: j['downloadEnabled'] ?? false,
    isDigitalSale: j['isDigitalSale'] ?? false,
    isEbook: j['isEbook'] ?? false,
    digitalPrice: (j['digitalPrice'] ?? 0).toDouble(),
    digitalPriceDisplay: j['digitalPriceDisplay'],
    publicationYear: j['publicationYear'],
    pages: j['pages'],
    readingPageCount: j['readingPageCount'],
  );

  static List<String> _extractNames(dynamic list) {
    if (list == null) return [];
    if (list is List) return list.map((e) => e is Map ? e['name']?.toString() ?? '' : e.toString()).where((s) => s.isNotEmpty).toList();
    return [];
  }

  bool get isAvailable => availableCopies > 0;
  bool get isDigital => bookType == 'digital' || bookType == 'both';
  bool get isPhysical => bookType == 'physical' || bookType == 'both' || bookType == null;
}
