class BlogPost {
  final String id, title;
  final String? slug, excerpt, content, coverImage, category, subCategory, authorName;
  final List<String> tags;
  final bool featured;
  final int views, readTime;
  final DateTime? publishedAt;

  BlogPost({required this.id, required this.title, this.slug, this.excerpt,
    this.content, this.coverImage, this.category, this.subCategory,
    this.authorName, this.tags = const [], this.featured = false,
    this.views = 0, this.readTime = 0, this.publishedAt});

  factory BlogPost.fromJson(Map<String, dynamic> j) => BlogPost(
    id: j['_id'] ?? '', title: j['title'] ?? '',
    slug: j['slug'], excerpt: j['excerpt'], content: j['content'],
    coverImage: j['coverImage'], category: j['category'], subCategory: j['subCategory'],
    authorName: j['author'] is Map ? j['author']['name'] : null,
    tags: List<String>.from(j['tags'] ?? []),
    featured: j['featured'] ?? false, views: j['views'] ?? 0, readTime: j['readTime'] ?? 0,
    publishedAt: j['publishedAt'] != null ? DateTime.tryParse(j['publishedAt']) : null,
  );

  String get postId => slug ?? id;
}
