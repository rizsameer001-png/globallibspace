class UserModel {
  final String id, name, email, role;
  final bool isActive;
  final String? phone, avatar, membershipPlan;
  final DateTime? membershipExpiry;

  UserModel({required this.id, required this.name, required this.email,
    required this.role, this.isActive = true, this.phone, this.avatar,
    this.membershipPlan, this.membershipExpiry});

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    id: j['_id'] ?? '', name: j['name'] ?? '', email: j['email'] ?? '',
    role: j['role'] ?? 'member', isActive: j['isActive'] ?? true,
    phone: j['phone'], avatar: j['avatar'],
    membershipPlan: j['membershipPlan'] is Map ? j['membershipPlan']['name'] : j['membershipPlan']?.toString(),
    membershipExpiry: j['membershipExpiry'] != null ? DateTime.tryParse(j['membershipExpiry']) : null,
  );

  bool get isAdmin => role == 'admin' || role == 'manager';
  bool get isMember => role == 'member';
}
