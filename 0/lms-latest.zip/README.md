# City Library — Flutter App

Full-featured Flutter mobile app for the LMS (Library Management System).

## Features
- Browse & search books (physical + digital)
- Book detail with reserve, read online, download
- PDF reader with Text-to-Speech (TTS) narration
- Sentence highlight + speed control (0.5x – 2x)
- Bookmarks & reading progress tracking
- Author profiles (bio, books, videos, timeline)
- Blog with categories, rich HTML content
- My Books (borrowing history, overdue alerts)
- My Downloads with reading progress
- Authentication (login / register)
- User profile with membership info

## Project Structure
```
lib/
  core/          → theme, constants
  models/        → User, Book, Author, BlogPost, Circulation
  services/      → ApiService (Dio), AuthService
  providers/     → AuthProvider, BooksProvider
  screens/
    auth/        → login, register
    home/        → home with featured books, authors, blog
    books/       → browse, detail
    reader/      → PDF viewer + TTS
    authors/     → listing (A-Z), profile
    blog/        → listing, post detail
    member/      → my books, my downloads
  widgets/
    common/      → BookCard, SectionHeader, ShimmerList
```

## Setup

### 1. Configure API URL
Edit `lib/core/constants.dart`:
```dart
static const String baseUrl = 'https://your-lms-server.onrender.com/api';
// Local dev (Android emulator): 'http://10.0.2.2:5000/api'
// Local dev (iOS simulator):    'http://localhost:5000/api'
```

### 2. Install dependencies
```bash
flutter pub get
```

### 3. Run
```bash
flutter run
```

### 4. Build release APK
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

## Dependencies
| Package | Purpose |
|---|---|
| dio | HTTP client |
| provider | State management |
| shared_preferences | Token & user storage |
| cached_network_image | Image loading + caching |
| syncfusion_flutter_pdfviewer | PDF rendering |
| flutter_tts | Text-to-Speech |
| flutter_html | Rich HTML content rendering |
| google_fonts | Inter font |
| url_launcher | Open external URLs |
| shimmer | Loading placeholders |
| intl | Date formatting |
| percent_indicator | Progress bars |
